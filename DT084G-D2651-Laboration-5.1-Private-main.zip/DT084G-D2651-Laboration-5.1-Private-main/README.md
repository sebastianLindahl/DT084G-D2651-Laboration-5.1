# Labbgrund till Moment 5 i kursen DT084G, Introduktion till programmering i JavaScript
Använd dessa filer som grund till din laboration.

OBS: Uppdatera texten i denna README-fil så att den beskriver din labb, samt inkludera ditt namn och student-id.
